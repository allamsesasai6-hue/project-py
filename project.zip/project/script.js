/**
 * SmartCommunity Hack — Project #15: Bill Splitter
 * Architecture:
 * 1. Domain Constants & Threshold Rules
 * 2. Core Business Logic Engine (Exact Cents Rounding & Custom Weights)
 * 3. Defensive Input & Schema Validation Engine
 * 4. Fault-Tolerant LocalStorage Persistence with Corruption Recovery
 * 5. Seed Dataset Generator (35 Realistic + Boundary Records)
 * 6. Offline HTML5 Canvas Visualization Engine (Category Donut & Trend Bar)
 * 7. Multi-Format Exporter (JSON, CSV, Markdown) & Bulk CSV/JSON Importer
 */

const STORAGE_KEY = "smartcommunity_billsplitter_v1";
const ALLOWED_CATEGORIES = [
  "Dining & Food",
  "Groceries",
  "Travel & Transit",
  "Utilities & Rent",
  "Entertainment",
  "Study & Supplies"
];
const ALLOWED_STATUSES = ["Settled", "Pending", "Overdue"];

const THRESHOLDS = {
  HIGH_TOTAL: 250.0,
  HIGH_PER_PERSON: 75.0,
  HIGH_TIP_PCT: 25.0
};

const CATEGORY_COLORS = {
  "Dining & Food": "#38bdf8",
  "Groceries": "#34d399",
  "Travel & Transit": "#fbbf24",
  "Utilities & Rent": "#a78bfa",
  "Entertainment": "#f472b6",
  "Study & Supplies": "#fb923c"
};

let records = [];
let currentPage = 1;
const PAGE_SIZE = 10;

/* ==================== 1. CORE BUSINESS LOGIC ENGINE ==================== */
function roundMoney(num) {
  return Math.round((Number(num) + Number.EPSILON) * 100) / 100;
}

function formatUSD(num) {
  return "$" + roundMoney(num).toFixed(2);
}

function calculateSplit({ subtotal, tipPercent, peopleCount, splitMode = "equal", participants = [] }) {
  const cleanSub = roundMoney(subtotal);
  const cleanTipPct = Number(tipPercent);
  const count = Math.max(1, Math.min(100, Math.floor(Number(peopleCount))));

  const tipAmount = roundMoney(cleanSub * (cleanTipPct / 100));
  const grandTotal = roundMoney(cleanSub + tipAmount);

  let breakdown = [];

  if (splitMode === "custom" && Array.isArray(participants) && participants.length === count) {
    let allocatedBase = 0;
    let allocatedTip = 0;

    participants.forEach((p, idx) => {
      const ratio = Number(p.weight) / 100;
      let pBase, pTip;
      if (idx === count - 1) {
        pBase = roundMoney(cleanSub - allocatedBase);
        pTip = roundMoney(tipAmount - allocatedTip);
      } else {
        pBase = roundMoney(cleanSub * ratio);
        pTip = roundMoney(tipAmount * ratio);
        allocatedBase = roundMoney(allocatedBase + pBase);
        allocatedTip = roundMoney(allocatedTip + pTip);
      }
      breakdown.push({
        name: (p.name || `Person ${idx + 1}`).trim(),
        weight: roundMoney(p.weight),
        base: pBase,
        tip: pTip,
        total: roundMoney(pBase + pTip)
      });
    });
  } else {
    // Equal 1/N split with remainder cent distribution on final share
    const evenBase = Math.floor((cleanSub * 100) / count) / 100;
    const evenTip = Math.floor((tipAmount * 100) / count) / 100;
    let usedBase = 0;
    let usedTip = 0;

    for (let i = 0; i < count; i++) {
      const isLast = i === count - 1;
      const pBase = isLast ? roundMoney(cleanSub - usedBase) : evenBase;
      const pTip = isLast ? roundMoney(tipAmount - usedTip) : evenTip;
      usedBase = roundMoney(usedBase + pBase);
      usedTip = roundMoney(usedTip + pTip);

      breakdown.push({
        name: `Person ${i + 1}`,
        weight: roundMoney(100 / count),
        base: pBase,
        tip: pTip,
        total: roundMoney(pBase + pTip)
      });
    }
  }

  const perPersonAvg = roundMoney(grandTotal / count);
  const flags = evaluateThresholds({ grandTotal, perPersonAvg, tipPercent: cleanTipPct, status: "Pending" });

  return {
    subtotal: cleanSub,
    tipPercent: cleanTipPct,
    tipAmount,
    grandTotal,
    peopleCount: count,
    perPersonShare: perPersonAvg,
    breakdown,
    flags
  };
}

function evaluateThresholds({ grandTotal, perPersonAvg, tipPercent, status }) {
  const flags = [];
  if (status === "Overdue") flags.push("Overdue Settlement");
  if (grandTotal >= THRESHOLDS.HIGH_TOTAL) flags.push(`High Bill (≥$${THRESHOLDS.HIGH_TOTAL})`);
  if (perPersonAvg >= THRESHOLDS.HIGH_PER_PERSON) flags.push(`High Share (≥$${THRESHOLDS.HIGH_PER_PERSON}/person)`);
  if (tipPercent > THRESHOLDS.HIGH_TIP_PCT) flags.push(`High Tip (>${THRESHOLDS.HIGH_TIP_PCT}%)`);
  return flags;
}

/* ==================== 2. DEFENSIVE VALIDATION ENGINE ==================== */
function validateRecordInput(raw) {
  const errors = {};

  const title = typeof raw.title === "string" ? raw.title.trim() : "";
  if (!title || title.length < 2) {
    errors.billTitle = "Title must be at least 2 non-whitespace characters.";
  } else if (title.length > 80) {
    errors.billTitle = "Title cannot exceed 80 characters.";
  }

  const category = ALLOWED_CATEGORIES.includes(raw.category) ? raw.category : null;
  if (!category) {
    errors.billCategory = "Select a valid category.";
  }

  const dateStr = typeof raw.date === "string" ? raw.date.trim() : "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr) || Number.isNaN(Date.parse(dateStr))) {
    errors.billDate = "Enter a valid YYYY-MM-DD date.";
  }

  const subtotal = Number(raw.subtotal);
  if (!Number.isFinite(subtotal) || subtotal <= 0 || subtotal > 1000000) {
    errors.subtotal = "Subtotal must be between $0.01 and $1,000,000.";
  }

  const tipPercent = Number(raw.tipPercent);
  if (!Number.isFinite(tipPercent) || tipPercent < 0 || tipPercent > 100) {
    errors.tipPercent = "Tip percentage must be between 0% and 100%.";
  }

  const peopleCount = Number(raw.peopleCount);
  if (!Number.isInteger(peopleCount) || peopleCount < 1 || peopleCount > 100) {
    errors.peopleCount = "People count must be a whole number between 1 and 100.";
  }

  const status = ALLOWED_STATUSES.includes(raw.status) ? raw.status : "Pending";

  if (raw.splitMode === "custom" && Array.isArray(raw.participants)) {
    const sum = raw.participants.reduce((acc, p) => acc + (Number(p.weight) || 0), 0);
    if (Math.abs(sum - 100) > 0.05) {
      errors.customWeights = `Custom weights must sum to 100% (currently ${roundMoney(sum)}%).`;
    }
    const invalidWeight = raw.participants.some((p) => !Number.isFinite(Number(p.weight)) || Number(p.weight) < 0);
    if (invalidWeight) {
      errors.customWeights = "Each participant weight must be a non-negative number.";
    }
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
    sanitized: {
      title,
      category: category || "Dining & Food",
      date: dateStr,
      subtotal: roundMoney(subtotal),
      tipPercent: roundMoney(tipPercent),
      peopleCount,
      status,
      splitMode: raw.splitMode === "custom" ? "custom" : "equal",
      participants: raw.participants || [],
      notes: typeof raw.notes === "string" ? raw.notes.trim().slice(0, 140) : ""
    }
  };
}

/* ==================== 3. FAULT-TOLERANT PERSISTENCE ==================== */
function loadRecordsFromStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      records = generateSeedDataset();
      saveRecordsToStorage();
      showToast("Initialized clean local database with 35 hackathon test records.", "success");
      return;
    }

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      throw new Error("Root storage payload is not an array.");
    }

    const validRecords = [];
    let droppedCount = 0;

    parsed.forEach((item) => {
      const check = validateRecordInput(item);
      if (check.valid) {
        const calc = calculateSplit(check.sanitized);
        validRecords.push({
          id: item.id || generateId(),
          ...check.sanitized,
          tipAmount: calc.tipAmount,
          grandTotal: calc.grandTotal,
          perPersonShare: calc.perPersonShare,
          breakdown: calc.breakdown
        });
      } else {
        droppedCount++;
      }
    });

    if (validRecords.length === 0 && parsed.length > 0) {
      throw new Error("All stored entries failed schema validation.");
    }

    records = validRecords;
    if (droppedCount > 0) {
      saveRecordsToStorage();
      showToast(`Recovered storage: quarantined ${droppedCount} malformed record(s).`, "warning");
    }
  } catch (err) {
    console.error("Storage corruption detected:", err);
    records = generateSeedDataset();
    saveRecordsToStorage();
    updateStoragePill(true);
    showToast(`Corrupted storage detected (${err.message}). Auto-rebuilt clean 35-record schema!`, "warning");
  }
}

function saveRecordsToStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
    updateStoragePill(false);
  } catch (err) {
    showToast("Failed to write to LocalStorage: " + err.message, "error");
  }
}

function updateStoragePill(recovered) {
  const pill = document.getElementById("storageStatus");
  if (!pill) return;
  pill.innerHTML = recovered
    ? `<span class="dot warn"></span><span>Schema Auto-Recovered</span>`
    : `<span class="dot ok"></span><span>LocalStorage Synced (${records.length})</span>`;
}

function generateId() {
  return "BS-" + Math.random().toString(36).substring(2, 7).toUpperCase();
}

/* ==================== 4. SEED DATASET (35 REALISTIC & EDGE CASES) ==================== */
function generateSeedDataset() {
  const samples = [
    ["Hackathon Kickoff Pizza", "Dining & Food", "2026-11-18", 84.50, 15, 5, "Settled", "Paid by Yashwanth"],
    ["Monthly Fiber Internet", "Utilities & Rent", "2026-11-17", 60.00, 0, 3, "Settled", "Zero-tip utility boundary test"],
    ["Airport Cab Share", "Travel & Transit", "2026-11-16", 48.00, 10, 4, "Pending", "Morning flight group"],
    ["Weekly Organic Groceries", "Groceries", "2026-11-15", 132.40, 5, 4, "Settled", "Shared kitchen restock"],
    ["IMAX Sci-Fi Movie Night", "Entertainment", "2026-11-14", 72.00, 0, 4, "Settled", "Tickets booked online"],
    ["Biryani Feast Celebration", "Dining & Food", "2026-11-13", 110.00, 18, 6, "Settled", "Post-exam dinner"],
    ["Microcontroller Lab Kit", "Study & Supplies", "2026-11-12", 95.00, 0, 3, "Overdue", "Hardware prototype sensors"],
    ["Group Airbnb Weekend", "Travel & Transit", "2026-11-11", 420.00, 12, 4, "Overdue", "High-value & overdue threshold trigger"],
    ["Coffee & Debugging Sprint", "Dining & Food", "2026-11-10", 24.50, 20, 3, "Settled", "Late night coding fuel"],
    ["Apartment Electricity Bill", "Utilities & Rent", "2026-11-09", 145.80, 0, 3, "Pending", "October cycle"],
    ["Bowling & Arcade Night", "Entertainment", "2026-11-08", 88.00, 15, 4, "Settled", "Weekend hangout"],
    ["Bulk Rice & Pantry Staples", "Groceries", "2026-11-07", 67.25, 0, 3, "Settled", "Wholesale store run"],
    ["Intercity Train Tickets", "Travel & Transit", "2026-11-06", 156.00, 0, 4, "Settled", "Conference travel"],
    ["Fine Dining Anniversary", "Dining & Food", "2026-11-05", 260.00, 28, 3, "Pending", "High tip & high per-person trigger"],
    ["Soldering Station & Wires", "Study & Supplies", "2026-11-04", 54.00, 0, 2, "Settled", "Electronics bench"],
    ["Co-working Day Pass", "Study & Supplies", "2026-11-03", 75.00, 10, 5, "Settled", "Hackathon prep"],
    ["Sushi & Ramen Dinner", "Dining & Food", "2026-11-02", 92.00, 18, 4, "Settled", "Downtown spot"],
    ["Concert Group Tickets", "Entertainment", "2026-11-01", 310.00, 8, 4, "Overdue", "High bill & overdue alert"],
    ["Fresh Produce & Dairy", "Groceries", "2026-10-30", 41.30, 0, 3, "Settled", "Neighborhood market"],
    ["Water & Gas Utility", "Utilities & Rent", "2026-10-29", 52.00, 0, 3, "Settled", "Monthly split"],
    ["Single Espresso Boundary", "Dining & Food", "2026-10-28", 3.50, 15, 1, "Settled", "1-person boundary test"],
    ["Highway Toll & Fuel Split", "Travel & Transit", "2026-10-27", 64.80, 0, 4, "Settled", "Road trip leg 1"],
    ["3D Printing Filament Pack", "Study & Supplies", "2026-10-26", 48.00, 0, 3, "Pending", "PLA rolls"],
    ["Taco Tuesday Platter", "Dining & Food", "2026-10-25", 58.00, 15, 4, "Settled", "Campus canteen"],
    ["Board Game Cafe Entry", "Entertainment", "2026-10-24", 36.00, 10, 4, "Settled", "3-hour table"],
    ["Bakery & Breakfast Box", "Groceries", "2026-10-23", 29.40, 10, 3, "Settled", "Sunday brunch"],
    ["Metro Smart Cards Top-up", "Travel & Transit", "2026-10-22", 40.00, 0, 4, "Settled", "Commute passes"],
    ["Cloud Server Lab Credits", "Study & Supplies", "2026-10-21", 30.00, 0, 3, "Settled", "Shared test instance"],
    ["Burger & Fries Combo", "Dining & Food", "2026-10-20", 46.50, 15, 3, "Settled", "Quick lunch"],
    ["Streaming Family Plan", "Entertainment", "2026-10-19", 22.99, 0, 4, "Settled", "Odd-cent rounding check"],
    ["Cleaning & Household Goods", "Groceries", "2026-10-18", 38.75, 0, 3, "Settled", "Monthly supplies"],
    ["Late Night Auto Rickshaw", "Travel & Transit", "2026-10-17", 14.00, 10, 2, "Settled", "Station pickup"],
    ["Reference Textbooks Print", "Study & Supplies", "2026-10-16", 42.00, 0, 3, "Pending", "Spiral binding"],
    ["Ice Cream & Waffles", "Dining & Food", "2026-10-15", 27.00, 12, 3, "Settled", "Dessert run"],
    ["Large Group Banquet (12)", "Dining & Food", "2026-10-14", 360.00, 20, 12, "Settled", "12-person split edge case"]
  ];

  return samples.map((s, i) => {
    const raw = {
      title: s[0],
      category: s[1],
      date: s[2],
      subtotal: s[3],
      tipPercent: s[4],
      peopleCount: s[5],
      status: s[6],
      notes: s[7],
      splitMode: "equal"
    };
    const calc = calculateSplit(raw);
    return {
      id: `BS-${String(1001 + i)}`,
      ...raw,
      tipAmount: calc.tipAmount,
      grandTotal: calc.grandTotal,
      perPersonShare: calc.perPersonShare,
      breakdown: calc.breakdown
    };
  });
}

/* ==================== 5. UI RENDERING & LIVE CALCULATOR ==================== */
function getCustomParticipantsFromUI() {
  const rows = document.querySelectorAll("#participantsList .participant-row");
  return Array.from(rows).map((row, idx) => ({
    name: row.querySelector(".p-name").value.trim() || `Person ${idx + 1}`,
    weight: Number(row.querySelector(".p-weight").value) || 0
  }));
}

function rebuildParticipantInputs() {
  const count = Math.max(1, Math.min(100, parseInt(document.getElementById("peopleCount").value, 10) || 1));
  const container = document.getElementById("participantsList");
  const existing = getCustomParticipantsFromUI();
  const equalWeight = roundMoney(100 / count);

  container.innerHTML = "";
  let runningWeight = 0;

  for (let i = 0; i < count; i++) {
    const defaultWeight = i === count - 1 ? roundMoney(100 - runningWeight) : equalWeight;
    runningWeight = roundMoney(runningWeight + defaultWeight);

    const nameVal = existing[i]?.name || `Person ${i + 1}`;
    const weightVal = existing.length === count ? existing[i].weight : defaultWeight;

    const row = document.createElement("div");
    row.className = "participant-row";
    row.innerHTML = `
      <input type="text" class="p-name" value="${escapeHtml(nameVal)}" placeholder="Participant ${i + 1}" />
      <input type="number" class="p-weight" value="${weightVal}" min="0" max="100" step="0.1" />
    `;
    row.querySelectorAll("input").forEach((inp) => inp.addEventListener("input", updateLivePreview));
    container.appendChild(row);
  }
  updateLivePreview();
}

function updateLivePreview() {
  const subtotal = Math.max(0, Number(document.getElementById("subtotal").value) || 0);
  const tipPercent = Math.max(0, Math.min(100, Number(document.getElementById("tipPercent").value) || 0));
  const peopleCount = Math.max(1, Math.min(100, parseInt(document.getElementById("peopleCount").value, 10) || 1));
  const splitMode = document.querySelector('input[name="splitMode"]:checked').value;
  const status = document.getElementById("billStatus").value;
  const participants = splitMode === "custom" ? getCustomParticipantsFromUI() : [];

  if (splitMode === "custom") {
    const sum = roundMoney(participants.reduce((a, b) => a + b.weight, 0));
    const pill = document.getElementById("weightSumIndicator");
    pill.textContent = `Total: ${sum}%`;
    pill.classList.toggle("bad", Math.abs(sum - 100) > 0.05);
  }

  const calc = calculateSplit({ subtotal, tipPercent, peopleCount, splitMode, participants });
  const flags = evaluateThresholds({
    grandTotal: calc.grandTotal,
    perPersonAvg: calc.perPersonShare,
    tipPercent,
    status
  });

  document.getElementById("prevSubtotal").textContent = formatUSD(calc.subtotal);
  document.getElementById("prevTipRate").textContent = tipPercent;
  document.getElementById("prevTipAmount").textContent = formatUSD(calc.tipAmount);
  document.getElementById("prevGrandTotal").textContent = formatUSD(calc.grandTotal);
  document.getElementById("prevPeople").textContent = peopleCount;
  document.getElementById("prevPerPerson").textContent =
    splitMode === "equal" ? formatUSD(calc.perPersonShare) : `${formatUSD(calc.perPersonShare)} avg`;

  // Threshold indicators
  const flagBadge = document.getElementById("thresholdFlagBadge");
  const warningBox = document.getElementById("liveWarningBox");

  if (flags.length > 0) {
    flagBadge.textContent = `${flags.length} Threshold Flag(s)`;
    flagBadge.className = "badge badge-warn";
    warningBox.classList.remove("hidden");
    warningBox.innerHTML = `<strong>⚠ Threshold Alert:</strong> ${flags.join(" • ")}`;
  } else {
    flagBadge.textContent = "Normal Threshold";
    flagBadge.className = "badge badge-ok";
    warningBox.classList.add("hidden");
  }

  // Breakdown table (cap visual preview to 25 rows if huge, note remainder)
  const tbody = document.getElementById("liveBreakdownBody");
  const displayRows = calc.breakdown.slice(0, 25);
  tbody.innerHTML = displayRows
    .map(
      (b) => `
    <tr>
      <td>${escapeHtml(b.name)}</td>
      <td class="mono">${b.weight.toFixed(1)}%</td>
      <td class="mono">${formatUSD(b.base)}</td>
      <td class="mono">${formatUSD(b.tip)}</td>
      <td class="mono"><strong>${formatUSD(b.total)}</strong></td>
    </tr>
  `
    )
    .join("");

  if (calc.breakdown.length > 25) {
    tbody.innerHTML += `<tr><td colspan="5" class="muted-text">...plus ${calc.breakdown.length - 25} more participants</td></tr>`;
  }
}

/* ==================== 6. ANALYTICS & OFFLINE CANVAS CHARTS ==================== */
function renderAnalytics() {
  const totalBills = records.length;
  const settledCount = records.filter((r) => r.status === "Settled").length;
  const grandSpend = roundMoney(records.reduce((s, r) => s + r.grandTotal, 0));
  const totalSub = roundMoney(records.reduce((s, r) => s + r.subtotal, 0));
  const totalTips = roundMoney(records.reduce((s, r) => s + r.tipAmount, 0));
  const avgBill = totalBills ? roundMoney(grandSpend / totalBills) : 0;
  const avgShare = totalBills ? roundMoney(records.reduce((s, r) => s + r.perPersonShare, 0) / totalBills) : 0;
  const avgGroup = totalBills ? (records.reduce((s, r) => s + r.peopleCount, 0) / totalBills).toFixed(1) : "0";
  const effTipPct = totalSub > 0 ? ((totalTips / totalSub) * 100).toFixed(1) : "0.0";

  const flaggedBills = records.filter(
    (r) =>
      evaluateThresholds({
        grandTotal: r.grandTotal,
        perPersonAvg: r.perPersonShare,
        tipPercent: r.tipPercent,
        status: r.status
      }).length > 0
  ).length;

  document.getElementById("kpiTotalBills").textContent = totalBills;
  document.getElementById("kpiSettledRatio").textContent = totalBills
    ? `${Math.round((settledCount / totalBills) * 100)}% Settled (${settledCount}/${totalBills})`
    : "0% Settled";
  document.getElementById("kpiGrandSpend").textContent = formatUSD(grandSpend);
  document.getElementById("kpiAvgBill").textContent = `Avg Bill: ${formatUSD(avgBill)}`;
  document.getElementById("kpiAvgShare").textContent = formatUSD(avgShare);
  document.getElementById("kpiAvgGroupSize").textContent = `Avg Group: ${avgGroup} people`;
  document.getElementById("kpiTotalTips").textContent = formatUSD(totalTips);
  document.getElementById("kpiAvgTipPct").textContent = `Effective Tip: ${effTipPct}%`;
  document.getElementById("kpiAlertCount").textContent = flaggedBills;

  // Aggregate by Category
  const catMap = {};
  ALLOWED_CATEGORIES.forEach((c) => {
    catMap[c] = { count: 0, sub: 0, tips: 0, total: 0, shareSum: 0 };
  });

  records.forEach((r) => {
    if (!catMap[r.category]) {
      catMap[r.category] = { count: 0, sub: 0, tips: 0, total: 0, shareSum: 0 };
    }
    catMap[r.category].count += 1;
    catMap[r.category].sub = roundMoney(catMap[r.category].sub + r.subtotal);
    catMap[r.category].tips = roundMoney(catMap[r.category].tips + r.tipAmount);
    catMap[r.category].total = roundMoney(catMap[r.category].total + r.grandTotal);
    catMap[r.category].shareSum = roundMoney(catMap[r.category].shareSum + r.perPersonShare);
  });

  const tbody = document.getElementById("categorySummaryBody");
  tbody.innerHTML = Object.entries(catMap)
    .map(([cat, d]) => {
      const pct = grandSpend > 0 ? ((d.total / grandSpend) * 100).toFixed(1) : "0.0";
      const avgCatShare = d.count > 0 ? formatUSD(d.shareSum / d.count) : "$0.00";
      return `
        <tr>
          <td><strong>${escapeHtml(cat)}</strong></td>
          <td class="mono">${d.count}</td>
          <td class="mono">${formatUSD(d.sub)}</td>
          <td class="mono">${formatUSD(d.tips)}</td>
          <td class="mono"><strong>${formatUSD(d.total)}</strong></td>
          <td class="mono">${avgCatShare}</td>
          <td class="mono">${pct}%</td>
        </tr>
      `;
    })
    .join("");

  drawCategoryDonutChart(catMap, grandSpend);
  drawTrendBarChart();
}

function drawCategoryDonutChart(catMap, grandSpend) {
  const canvas = document.getElementById("categoryChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  const entries = Object.entries(catMap).filter(([, d]) => d.total > 0);
  const legendEl = document.getElementById("categoryLegend");
  legendEl.innerHTML = "";

  if (entries.length === 0 || grandSpend <= 0) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "14px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("No bill data available for visualization", w / 2, h / 2);
    return;
  }

  const cx = w / 2;
  const cy = h / 2;
  const radius = Math.min(w, h) * 0.36;
  const innerRadius = radius * 0.56;
  let startAngle = -Math.PI / 2;

  entries.forEach(([cat, d]) => {
    const sliceAngle = (d.total / grandSpend) * Math.PI * 2;
    const color = CATEGORY_COLORS[cat] || "#38bdf8";

    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, radius, startAngle, startAngle + sliceAngle);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();

    startAngle += sliceAngle;

    const pct = ((d.total / grandSpend) * 100).toFixed(1);
    legendEl.innerHTML += `
      <span class="legend-item">
        <span class="legend-swatch" style="background:${color}"></span>
        <span>${escapeHtml(cat)} (${pct}%)</span>
      </span>
    `;
  });

  // Donut cutout
  ctx.beginPath();
  ctx.arc(cx, cy, innerRadius, 0, Math.PI * 2);
  ctx.fillStyle = "#0f172a";
  ctx.fill();

  ctx.fillStyle = "#f1f5f9";
  ctx.font = "bold 15px monospace";
  ctx.textAlign = "center";
  ctx.fillText(formatUSD(grandSpend), cx, cy + 4);
  ctx.fillStyle = "#94a3b8";
  ctx.font = "11px sans-serif";
  ctx.fillText("TOTAL SPEND", cx, cy - 14);
}

function drawTrendBarChart() {
  const canvas = document.getElementById("trendChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  const recent = [...records]
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-12);

  if (recent.length === 0) return;

  const pad = { top: 24, right: 20, bottom: 42, left: 54 };
  const plotW = w - pad.left - pad.right;
  const plotH = h - pad.top - pad.bottom;
  const maxVal = Math.max(...recent.map((r) => r.grandTotal), 10);

  // Horizontal grid lines
  ctx.strokeStyle = "#1e293b";
  ctx.fillStyle = "#94a3b8";
  ctx.font = "11px monospace";
  ctx.textAlign = "right";

  for (let i = 0; i <= 4; i++) {
    const val = (maxVal / 4) * i;
    const y = pad.top + plotH - (plotH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(pad.left, y);
    ctx.lineTo(w - pad.right, y);
    ctx.stroke();
    ctx.fillText("$" + Math.round(val), pad.left - 8, y + 4);
  }

  const slotW = plotW / recent.length;
  const barW = Math.min(28, slotW * 0.62);

  recent.forEach((r, idx) => {
    const x = pad.left + idx * slotW + (slotW - barW) / 2;
    const subH = (r.subtotal / maxVal) * plotH;
    const tipH = (r.tipAmount / maxVal) * plotH;

    // Subtotal bar
    ctx.fillStyle = "#38bdf8";
    ctx.fillRect(x, pad.top + plotH - subH, barW, subH);

    // Tip stacked bar
    ctx.fillStyle = "#34d399";
    ctx.fillRect(x, pad.top + plotH - subH - tipH, barW, tipH);

    // Date label
    ctx.fillStyle = "#94a3b8";
    ctx.font = "10px monospace";
    ctx.textAlign = "center";
    ctx.fillText(r.date.slice(5), x + barW / 2, h - 18);
  });

  // Legend top-left
  ctx.fillStyle = "#38bdf8";
  ctx.fillRect(pad.left, 6, 10, 10);
  ctx.fillStyle = "#cbd5e1";
  ctx.font = "11px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("Subtotal", pad.left + 15, 15);

  ctx.fillStyle = "#34d399";
  ctx.fillRect(pad.left + 75, 6, 10, 10);
  ctx.fillStyle = "#cbd5e1";
  ctx.fillText("Tip", pad.left + 90, 15);
}

/* ==================== 7. PERSISTENT LEDGER & SEARCH ==================== */
function getFilteredRecords() {
  const q = document.getElementById("searchQuery").value.trim().toLowerCase();
  const cat = document.getElementById("filterCategory").value;
  const status = document.getElementById("filterStatus").value;
  const sort = document.getElementById("sortOrder").value;

  let list = records.filter((r) => {
    const flags = evaluateThresholds({
      grandTotal: r.grandTotal,
      perPersonAvg: r.perPersonShare,
      tipPercent: r.tipPercent,
      status: r.status
    });

    if (cat !== "ALL" && r.category !== cat) return false;
    if (status === "FLAGGED" && flags.length === 0) return false;
    if (status !== "ALL" && status !== "FLAGGED" && r.status !== status) return false;

    if (q) {
      const hay = `${r.id} ${r.title} ${r.category} ${r.notes} ${r.date}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  list.sort((a, b) => {
    if (sort === "date-desc") return b.date.localeCompare(a.date);
    if (sort === "date-asc") return a.date.localeCompare(b.date);
    if (sort === "total-desc") return b.grandTotal - a.grandTotal;
    if (sort === "share-desc") return b.perPersonShare - a.perPersonShare;
    return 0;
  });

  return list;
}

function renderRecordsTable() {
  document.getElementById("recordCountBadge").textContent = records.length;
  const filtered = getFilteredRecords();
  document.getElementById("filteredCountLabel").textContent = `Showing ${filtered.length} of ${records.length} records`;

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  if (currentPage > totalPages) currentPage = totalPages;

  const start = (currentPage - 1) * PAGE_SIZE;
  const pageItems = filtered.slice(start, start + PAGE_SIZE);

  const tbody = document.getElementById("recordsTableBody");
  if (pageItems.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11" class="muted-text">No records match your current search or filter criteria.</td></tr>`;
  } else {
    tbody.innerHTML = pageItems
      .map((r) => {
        const flags = evaluateThresholds({
          grandTotal: r.grandTotal,
          perPersonAvg: r.perPersonShare,
          tipPercent: r.tipPercent,
          status: r.status
        });
        const statusClass =
          r.status === "Settled" ? "badge-ok" : r.status === "Overdue" ? "badge-danger" : "badge-warn";

        return `
          <tr>
            <td class="mono">${escapeHtml(r.id)}</td>
            <td class="mono">${escapeHtml(r.date)}</td>
            <td>
              <strong>${escapeHtml(r.title)}</strong>
              ${r.notes ? `<div class="subtitle">${escapeHtml(r.notes)}</div>` : ""}
            </td>
            <td>${escapeHtml(r.category)}</td>
            <td class="mono">${formatUSD(r.subtotal)}</td>
            <td class="mono">${r.tipPercent}%</td>
            <td class="mono"><strong>${formatUSD(r.grandTotal)}</strong></td>
            <td class="mono">${r.peopleCount}p (${r.splitMode})</td>
            <td class="mono">${formatUSD(r.perPersonShare)}</td>
            <td>
              <span class="badge ${statusClass}">${escapeHtml(r.status)}</span>
              ${flags.length ? `<div class="subtitle" style="color:#fbbf24;margin-top:3px;">⚠ ${escapeHtml(flags[0])}</div>` : ""}
            </td>
            <td>
              <div style="display:flex;gap:6px;">
                <button class="btn btn-ghost btn-sm" onclick="openRecordModal('${r.id}')">View</button>
                <button class="btn btn-ghost btn-sm" onclick="toggleRecordStatus('${r.id}')" title="Cycle Status">↻</button>
                <button class="btn btn-ghost btn-sm" onclick="deleteRecord('${r.id}')" title="Delete">✕</button>
              </div>
            </td>
          </tr>
        `;
      })
      .join("");
  }

  document.getElementById("paginationInfo").textContent = `Page ${currentPage} of ${totalPages}`;
  document.getElementById("btnPrevPage").disabled = currentPage <= 1;
  document.getElementById("btnNextPage").disabled = currentPage >= totalPages;
}

window.openRecordModal = function (id) {
  const rec = records.find((r) => r.id === id);
  if (!rec) return;

  document.getElementById("modalTitle").textContent = `${rec.id} — ${rec.title}`;
  const rowsHtml = (rec.breakdown || [])
    .map(
      (b) => `
      <tr>
        <td>${escapeHtml(b.name)}</td>
        <td class="mono">${b.weight}%</td>
        <td class="mono">${formatUSD(b.base)}</td>
        <td class="mono">${formatUSD(b.tip)}</td>
        <td class="mono"><strong>${formatUSD(b.total)}</strong></td>
      </tr>
    `
    )
    .join("");

  document.getElementById("modalBody").innerHTML = `
    <p class="muted-text">
      <strong>Date:</strong> ${escapeHtml(rec.date)} • 
      <strong>Category:</strong> ${escapeHtml(rec.category)} • 
      <strong>Status:</strong> ${escapeHtml(rec.status)}
    </p>
    ${rec.notes ? `<p class="muted-text"><strong>Notes:</strong> ${escapeHtml(rec.notes)}</p>` : ""}
    <div class="receipt-box" style="margin-bottom:14px;">
      <div class="receipt-line"><span>Subtotal</span><strong>${formatUSD(rec.subtotal)}</strong></div>
      <div class="receipt-line"><span>Tip (${rec.tipPercent}%)</span><strong>${formatUSD(rec.tipAmount)}</strong></div>
      <div class="receipt-line total-line"><span>Grand Total</span><strong>${formatUSD(rec.grandTotal)}</strong></div>
    </div>
    <div class="table-wrap" style="max-height:240px;overflow-y:auto;">
      <table class="compact-table">
        <thead><tr><th>Participant</th><th>Share</th><th>Base</th><th>Tip</th><th>Total</th></tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>
  `;
  document.getElementById("detailModal").classList.remove("hidden");
};

window.toggleRecordStatus = function (id) {
  const rec = records.find((r) => r.id === id);
  if (!rec) return;
  const nextIdx = (ALLOWED_STATUSES.indexOf(rec.status) + 1) % ALLOWED_STATUSES.length;
  rec.status = ALLOWED_STATUSES[nextIdx];
  saveRecordsToStorage();
  refreshAllViews();
  showToast(`Updated ${rec.id} status to ${rec.status}.`, "success");
};

window.deleteRecord = function (id) {
  records = records.filter((r) => r.id !== id);
  saveRecordsToStorage();
  refreshAllViews();
  showToast(`Deleted record ${id}.`, "warning");
};

/* ==================== 8. EXPORT & BULK IMPORT ==================== */
function buildMarkdownReport() {
  const totalBills = records.length;
  const grandSpend = roundMoney(records.reduce((s, r) => s + r.grandTotal, 0));
  const totalTips = roundMoney(records.reduce((s, r) => s + r.tipAmount, 0));
  const avgShare = totalBills ? roundMoney(records.reduce((s, r) => s + r.perPersonShare, 0) / totalBills) : 0;
  const flagged = records.filter(
    (r) =>
      evaluateThresholds({
        grandTotal: r.grandTotal,
        perPersonAvg: r.perPersonShare,
        tipPercent: r.tipPercent,
        status: r.status
      }).length > 0
  );

  let md = `# SmartCommunity Hack — Bill Splitter Executive Audit Report
`;
  md += `Generated: ${new Date().toISOString()}

`;
  md += `## 1. Executive Summary Metrics
`;
  md += `- **Total Records:** ${totalBills}
`;
  md += `- **Cumulative Spend:** ${formatUSD(grandSpend)}
`;
  md += `- **Total Tips Paid:** ${formatUSD(totalTips)}
`;
  md += `- **Average Per-Person Share:** ${formatUSD(avgShare)}
`;
  md += `- **Threshold Alerts Flagged:** ${flagged.length}

`;

  md += `## 2. Threshold Warning Flags
`;
  if (flagged.length === 0) {
    md += `_No overdue or high-threshold anomalies detected._

`;
  } else {
    flagged.forEach((r) => {
      const f = evaluateThresholds({
        grandTotal: r.grandTotal,
        perPersonAvg: r.perPersonShare,
        tipPercent: r.tipPercent,
        status: r.status
      });
      md += `- **${r.id} (${r.title})** [${r.date}]: ${formatUSD(r.grandTotal)} total — _${f.join(", ")}_
`;
    });
    md += `
`;
  }

  md += `## 3. Ledger Entries
`;
  md += `| ID | Date | Title | Category | Subtotal | Tip% | Total | People | Per Person | Status |
`;
  md += `|---|---|---|---|---:|---:|---:|---:|---:|---|
`;
  records.forEach((r) => {
    md += `| ${r.id} | ${r.date} | ${r.title} | ${r.category} | ${formatUSD(r.subtotal)} | ${r.tipPercent}% | ${formatUSD(r.grandTotal)} | ${r.peopleCount} | ${formatUSD(r.perPersonShare)} | ${r.status} |
`;
  });

  return md;
}

function buildCSVContent() {
  const header = "id,title,category,date,subtotal,tipPercent,tipAmount,grandTotal,peopleCount,perPersonShare,status,notes";
  const rows = records.map((r) =>
    [
      r.id,
      `"${(r.title || "").replace(/"/g, '""')}"`,
      `"${r.category}"`,
      r.date,
      r.subtotal.toFixed(2),
      r.tipPercent,
      r.tipAmount.toFixed(2),
      r.grandTotal.toFixed(2),
      r.peopleCount,
      r.perPersonShare.toFixed(2),
      r.status,
      `"${(r.notes || "").replace(/"/g, '""')}"`
    ].join(",")
  );
  return [header, ...rows].join("
");
}

function downloadFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function parseCSVLine(line) {
  const result = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && line[i + 1] === '"') {
      cur += '"';
      i++;
    } else if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === "," && !inQuotes) {
      result.push(cur.trim());
      cur = "";
    } else {
      cur += ch;
    }
  }
  result.push(cur.trim());
  return result;
}

function processBulkImport(rawText) {
  const logBox = document.getElementById("importLogBox");
  logBox.classList.remove("hidden");
  const logs = [];
  let importedCount = 0;
  let errorCount = 0;

  const trimmed = rawText.trim();
  if (!trimmed) {
    logBox.textContent = "[ERROR] No input data provided.";
    return;
  }

  let candidateRows = [];

  if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
    try {
      const parsed = JSON.parse(trimmed);
      candidateRows = Array.isArray(parsed) ? parsed : [parsed];
    } catch (e) {
      logBox.textContent = `[FATAL JSON PARSE ERROR] ${e.message}`;
      return;
    }
  } else {
    const lines = trimmed.split(/?
/).filter((l) => l.trim().length > 0);
    const startIdx = lines[0].toLowerCase().includes("subtotal") ? 1 : 0;
    for (let i = startIdx; i < lines.length; i++) {
      const cols = parseCSVLine(lines[i]);
      candidateRows.push({
        _rowNum: i + 1,
        title: cols[0],
        category: cols[1],
        date: cols[2],
        subtotal: cols[3],
        tipPercent: cols[4],
        peopleCount: cols[5],
        status: cols[6] || "Pending",
        notes: cols[7] || ""
      });
    }
  }

  candidateRows.forEach((row, idx) => {
    const rowLabel = row._rowNum ? `Row ${row._rowNum}` : `Item ${idx + 1}`;
    const check = validateRecordInput(row);
    if (!check.valid) {
      errorCount++;
      logs.push(`[REJECTED] ${rowLabel} ("${row.title || "Untitled"}") -> ${Object.values(check.errors).join(" | ")}`);
    } else {
      const calc = calculateSplit(check.sanitized);
      records.unshift({
        id: generateId(),
        ...check.sanitized,
        tipAmount: calc.tipAmount,
        grandTotal: calc.grandTotal,
        perPersonShare: calc.perPersonShare,
        breakdown: calc.breakdown
      });
      importedCount++;
      logs.push(`[OK] ${rowLabel} imported: "${check.sanitized.title}" (${formatUSD(calc.grandTotal)})`);
    }
  });

  if (importedCount > 0) {
    saveRecordsToStorage();
    refreshAllViews();
  }

  logs.unshift(`=== IMPORT COMPLETE: ${importedCount} Accepted | ${errorCount} Rejected ===
`);
  logBox.textContent = logs.join("
");
  showToast(`Bulk import finished: ${importedCount} added, ${errorCount} rejected.`, importedCount > 0 ? "success" : "warning");
}

/* ==================== 9. HELPERS & EVENT WIRING ==================== */
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function showToast(message, type = "success") {
  const container = document.getElementById("alertContainer");
  const div = document.createElement("div");
  div.className = `toast ${type}`;
  div.innerHTML = `<span>${escapeHtml(message)}</span><button class="btn btn-ghost btn-sm" onclick="this.parentElement.remove()">✕</button>`;
  container.appendChild(div);
  setTimeout(() => div.remove(), 5500);
}

function refreshAllViews() {
  renderRecordsTable();
  renderAnalytics();
  const prevBox = document.getElementById("exportPreview");
  if (prevBox) prevBox.value = buildMarkdownReport();
}

document.addEventListener("DOMContentLoaded", () => {
  // Default date to today
  document.getElementById("billDate").value = new Date().toISOString().split("T")[0];

  loadRecordsFromStorage();
  rebuildParticipantInputs();
  refreshAllViews();

  // Tab Navigation
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`tab-${btn.dataset.tab}`).classList.add("active");
      if (btn.dataset.tab === "analytics") renderAnalytics();
    });
  });

  // Tip Preset Chips
  document.querySelectorAll(".tip-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      document.querySelectorAll(".tip-chip").forEach((c) => c.classList.remove("active"));
      chip.classList.add("active");
      document.getElementById("tipPercent").value = chip.dataset.tip;
      updateLivePreview();
    });
  });

  document.getElementById("tipPercent").addEventListener("input", () => {
    document.querySelectorAll(".tip-chip").forEach((c) => c.classList.remove("active"));
    updateLivePreview();
  });

  // Live preview triggers
  ["subtotal", "billStatus"].forEach((id) => {
    document.getElementById(id).addEventListener("input", updateLivePreview);
  });

  document.getElementById("peopleCount").addEventListener("input", rebuildParticipantInputs);

  document.querySelectorAll('input[name="splitMode"]').forEach((radio) => {
    radio.addEventListener("change", (e) => {
      const customBox = document.getElementById("customSplitContainer");
      if (e.target.value === "custom") {
        customBox.classList.remove("hidden");
        rebuildParticipantInputs();
      } else {
        customBox.classList.add("hidden");
        updateLivePreview();
      }
    });
  });

  // Form Submission with Defensive Validation
  document.getElementById("billForm").addEventListener("submit", (e) => {
    e.preventDefault();
    document.querySelectorAll(".field-error").forEach((el) => (el.textContent = ""));
    document.querySelectorAll("input").forEach((el) => el.classList.remove("invalid"));

    const splitMode = document.querySelector('input[name="splitMode"]:checked').value;
    const rawPayload = {
      title: document.getElementById("billTitle").value,
      category: document.getElementById("billCategory").value,
      date: document.getElementById("billDate").value,
      subtotal: document.getElementById("subtotal").value,
      tipPercent: document.getElementById("tipPercent").value,
      peopleCount: document.getElementById("peopleCount").value,
      status: document.getElementById("billStatus").value,
      splitMode,
      participants: splitMode === "custom" ? getCustomParticipantsFromUI() : [],
      notes: document.getElementById("billNotes").value
    };

    const validation = validateRecordInput(rawPayload);
    if (!validation.valid) {
      Object.entries(validation.errors).forEach(([field, msg]) => {
        const errEl = document.getElementById(`err-${field}`);
        const inpEl = document.getElementById(field);
        if (errEl) errEl.textContent = msg;
        if (inpEl) inpEl.classList.add("invalid");
      });
      showToast("Validation blocked invalid input. Check highlighted fields.", "error");
      return;
    }

    const calc = calculateSplit(validation.sanitized);
    const newRecord = {
      id: generateId(),
      ...validation.sanitized,
      tipAmount: calc.tipAmount,
      grandTotal: calc.grandTotal,
      perPersonShare: calc.perPersonShare,
      breakdown: calc.breakdown
    };

    records.unshift(newRecord);
    saveRecordsToStorage();
    refreshAllViews();

    showToast(`Saved ${newRecord.id} (${formatUSD(newRecord.grandTotal)} • ${formatUSD(newRecord.perPersonShare)}/person).`, "success");
    document.getElementById("billTitle").value = "";
    document.getElementById("subtotal").value = "";
    document.getElementById("billNotes").value = "";
    updateLivePreview();
  });

  document.getElementById("btnClearForm").addEventListener("click", () => {
    document.getElementById("billForm").reset();
    document.getElementById("billDate").value = new Date().toISOString().split("T")[0];
    document.getElementById("customSplitContainer").classList.add("hidden");
    document.querySelectorAll(".field-error").forEach((el) => (el.textContent = ""));
    updateLivePreview();
  });

  // Search & Filter Listeners
  ["searchQuery", "filterCategory", "filterStatus", "sortOrder"].forEach((id) => {
    document.getElementById(id).addEventListener("input", () => {
      currentPage = 1;
      renderRecordsTable();
    });
  });

  document.getElementById("btnPrevPage").addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage--;
      renderRecordsTable();
    }
  });

  document.getElementById("btnNextPage").addEventListener("click", () => {
    currentPage++;
    renderRecordsTable();
  });

  // Demo Reset & Corruption Recovery Simulation
  document.getElementById("btnSeedReset").addEventListener("click", () => {
    records = generateSeedDataset();
    saveRecordsToStorage();
    currentPage = 1;
    refreshAllViews();
    showToast("Dataset reset to 35 realistic & boundary test records.", "success");
  });

  document.getElementById("btnSimulateCorruption").addEventListener("click", () => {
    localStorage.setItem(STORAGE_KEY, "{CORRUPTED_JSON_PAYLOAD_%%%");
    loadRecordsFromStorage();
    refreshAllViews();
  });

  // Exports
  document.getElementById("btnExportJSON").addEventListener("click", () => {
    downloadFile("bill-splitter-records.json", JSON.stringify(records, null, 2), "application/json");
  });

  document.getElementById("btnExportCSV").addEventListener("click", () => {
    downloadFile("bill-splitter-records.csv", buildCSVContent(), "text/csv");
  });

  document.getElementById("btnExportMD").addEventListener("click", () => {
    downloadFile("bill-splitter-audit-report.md", buildMarkdownReport(), "text/markdown");
  });

  // Bulk Import
  document.getElementById("fileImportInput").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      document.getElementById("rawImportText").value = ev.target.result;
    };
    reader.readAsText(file);
  });

  document.getElementById("btnLoadSampleCSV").addEventListener("click", () => {
    document.getElementById("rawImportText").value = [
      "title,category,date,subtotal,tipPercent,peopleCount,status,notes",
      "Robotics Club Lunch,Dining & Food,2026-11-19,125.00,15,5,Settled,Valid row 1",
      "Invalid Negative Subtotal,Groceries,2026-11-19,-45.00,10,3,Pending,Should reject negative amount",
      "Invalid People Count (150),Travel & Transit,2026-11-19,200.00,10,150,Pending,Exceeds 100 max limit",
      "Cloud Hosting Split,Utilities & Rent,2026-11-19,89.99,0,3,Overdue,Valid overdue threshold row"
    ].join("
");
  });

  document.getElementById("btnRunImport").addEventListener("click", () => {
    processBulkImport(document.getElementById("rawImportText").value);
  });

  // Modal Close
  document.getElementById("btnCloseModal").addEventListener("click", () => {
    document.getElementById("detailModal").classList.add("hidden");
  });

  document.getElementById("detailModal").addEventListener("click", (e) => {
    if (e.target.id === "detailModal") {
      document.getElementById("detailModal").classList.add("hidden");
    }
  });
});
